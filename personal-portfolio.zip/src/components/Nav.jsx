'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const links = [
	{
		name: 'Главная',
		path: '/',
	},
	{
		name: 'Обо мне',
		path: '/services',
	},
	{
		name: 'Резюме',
		path: '/resume',
	},
	{
		name: 'Проекты',
		path: '/work',
	},
	{
		name: 'Контакты',
		path: '/contact',
	},
]

const Nav = () => {
	const pathname = usePathname()
	return (
		<nav className='flex gap-8'>
			{links.map(link => {
				return (
					<Link
						href={link.path}
						key={link.path}
						className={`${link.path === pathname && 'text-accent border-b-2 border-accent'} font-medium hover:text-accent transition-all`}
					>
						{link.name}
					</Link>
				)
			})}
		</nav>
	)
}

export default Nav
